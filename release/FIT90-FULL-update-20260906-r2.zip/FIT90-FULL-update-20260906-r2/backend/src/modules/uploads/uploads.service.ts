import { BadRequestException, Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { existsSync, mkdirSync, writeFileSync } from 'fs';
import { join } from 'path';

interface CategoryCfg {
  dir: string;
  mimes: RegExp;
  maxBytes: number;
  prefix: string;
}

/**
 * MIME → safe on-disk extension. The saved extension is ALWAYS derived from the
 * validated MIME type here — never from the client-supplied filename — so a
 * `shell.php` uploaded as `image/png` can never land with an executable `.php`
 * extension (defence against RCE when the uploads dir is served by Apache).
 */
const MIME_EXT: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/png': 'png',
  'image/gif': 'gif',
  'image/webp': 'webp',
  'image/svg+xml': 'svg',
  'application/pdf': 'pdf',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/vnd.ms-powerpoint': 'ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
};

/** Upload categories → legacy on-disk folders, allowed types, size caps. */
const CATEGORIES: Record<string, CategoryCfg> = {
  'emp-photo': {
    dir: 'human_resources/emp_photo',
    mimes: /^image\/(jpe?g|png|gif|webp)$/,
    maxBytes: 5 * 1024 * 1024,
    prefix: 'emp',
  },
  'emp-bank': {
    dir: 'human_resources/emp_banks',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'bank',
  },
  signature: {
    dir: 'emp_signatures',
    mimes: /^image\/(jpe?g|png|webp)$/,
    maxBytes: 2 * 1024 * 1024,
    prefix: 'sign',
  },
  document: {
    dir: 'human_resources/emp_mostnad_files',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf|application\/msword|application\/vnd\.[a-z.-]+)$/,
    maxBytes: 20 * 1024 * 1024,
    prefix: 'doc',
  },
  logo: {
    dir: 'main',
    mimes: /^image\/(jpe?g|png|gif|webp|svg\+xml)$/,
    maxBytes: 5 * 1024 * 1024,
    prefix: 'main',
  },
  // --- parity-wave categories (agents, activities, legal files, messaging attachments) ---
  'club-content': {
    dir: 'club/content',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf|application\/msword|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document)$/,
    maxBytes: 20 * 1024 * 1024,
    prefix: 'cms',
  },
  'club-member': {
    dir: 'club/members',
    mimes: /^image\/(jpe?g|png|webp)$/,
    maxBytes: 5 * 1024 * 1024,
    prefix: 'club',
  },
  inbody: {
    dir: 'club/inbody',
    mimes: /^(image\/(jpe?g|png|webp|gif)|application\/pdf)$/,
    maxBytes: 15 * 1024 * 1024,
    prefix: 'inbody',
  },
  nutrition: {
    dir: 'club/nutrition',
    mimes: /^(image\/(jpe?g|png|webp|gif)|application\/pdf|application\/msword|application\/vnd\.openxmlformats-officedocument\.wordprocessingml\.document)$/,
    maxBytes: 20 * 1024 * 1024,
    prefix: 'nutrition',
  },
  'product-image': {
    dir: 'gym-sales/products',
    mimes: /^image\/(jpe?g|png|webp)$/,
    maxBytes: 5 * 1024 * 1024,
    prefix: 'prod',
  },
  'storage-doc': {
    dir: 'gym-sales/storages',
    mimes: /^(image\/(jpe?g|png|webp)|application\/pdf)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'stor',
  },
  'procurement-doc': {
    dir: 'gym-sales/procurement',
    mimes: /^(image\/(jpe?g|png|webp)|application\/pdf)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'prc',
  },
  agent: {
    dir: 'agents',
    mimes: /^image\/(jpe?g|png|gif|webp)$/,
    maxBytes: 5 * 1024 * 1024,
    prefix: 'agent',
  },
  activity: {
    dir: 'nashat',
    mimes: /^image\/(jpe?g|png|gif|webp)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'nashat',
  },
  app: {
    dir: 'mobile_app',
    mimes: /^image\/(jpe?g|png|gif|webp)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'app',
  },
  legal: {
    dir: 'files',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf|application\/msword|application\/vnd\.[a-z.-]+)$/,
    maxBytes: 25 * 1024 * 1024,
    prefix: 'layha',
  },
  message: {
    dir: 'human_resources/msg_files',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf|application\/msword|application\/vnd\.[a-z.-]+)$/,
    maxBytes: 20 * 1024 * 1024,
    prefix: 'msg',
  },
  event: {
    dir: 'club/events',
    mimes: /^image\/(jpe?g|png|gif|webp)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'event',
  },
  'event-consent': {
    dir: 'club/events/consents',
    mimes: /^(image\/(jpe?g|png|gif|webp)|application\/pdf)$/,
    maxBytes: 10 * 1024 * 1024,
    prefix: 'consent',
  },
};

@Injectable()
export class UploadsService {
  constructor(private readonly config: ConfigService) {}

  store(category: string, file: Express.Multer.File): { path: string; filename: string; url: string } {
    const cfg = CATEGORIES[category];
    if (!cfg) throw new BadRequestException('فئة الرفع غير صحيحة');
    if (!file) throw new BadRequestException('لم يتم إرفاق ملف');
    if (!cfg.mimes.test(file.mimetype)) throw new BadRequestException('نوع الملف غير مدعوم');
    if (file.size > cfg.maxBytes) throw new BadRequestException('حجم الملف أكبر من المسموح');

    // Extension comes from the validated MIME type, NOT the client filename, so an
    // executable extension (.php/.sh/…) can never be persisted even if the client
    // spoofs Content-Type or names the file shell.php.
    const ext = MIME_EXT[file.mimetype.toLowerCase()];
    if (!ext) throw new BadRequestException('نوع الملف غير مدعوم');

    const base = this.config.get<string>('uploadDir') ?? './uploads';
    const dirAbs = join(process.cwd(), base, cfg.dir);
    if (!existsSync(dirAbs)) mkdirSync(dirAbs, { recursive: true });
    const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.random().toString(36).slice(2, 12);
    const filename = `${cfg.prefix}-${stamp}${rand}.${ext}`;

    writeFileSync(join(dirAbs, filename), file.buffer);

    const relPath = `${cfg.dir}/${filename}`;
    const publicBase = this.config.get<string>('publicUploadBase') ?? '/uploads';
    return { path: relPath, filename, url: `${publicBase}/${relPath}` };
  }
}
