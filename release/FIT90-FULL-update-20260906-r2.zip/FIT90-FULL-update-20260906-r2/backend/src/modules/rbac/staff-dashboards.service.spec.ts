import { StaffDashboardsService } from './staff-dashboards.service';

describe('StaffDashboardsService', () => {
  it('includes subscriptions and clients assigned to the sales representative and totals this month receipts', async () => {
    const prisma: any = {
      users: { findUnique: jest.fn().mockResolvedValue({ emp_code: 7 }) },
      employees: { findUnique: jest.fn().mockResolvedValue({
        id: 7, employee: 'مندوب المبيعات', email: null, phone: null, personal_photo: null,
        branch_id_fk: 1, mosma_wazefy_n: 'مندوب مبيعات', employee_target: 1000, employee_commission: 10,
      }) },
      club_subscriptions: { findMany: jest.fn().mockResolvedValue([{
        id: 50, member_id: 22, customer_name: 'Client One', subscription_number: 'SUB001',
        subscription_type: 'Gold', registration_date: '2026-09-05', subscription_start_date: '2026-09-05',
        subscription_end_date: '2026-10-05', subscription_value: 800, paid_amount: 200,
        remaining_amount: 600, status: 'active', payment_method: 'cash',
      }]) },
      club_members: { findMany: jest.fn().mockResolvedValue([{ id: 22 }, { id: 23 }]) },
      club_receipts: { findMany: jest.fn().mockResolvedValue([{ amount: 400 }, { amount: 150 }]) },
    };
    const service = new StaffDashboardsService(prisma);

    const result = await service.salesDashboard(90, '2026-09');

    expect(result.summary).toEqual(expect.objectContaining({
      subscriptions: 1,
      customers: 2,
      totalSales: 800,
      collected: 550,
      outstanding: 600,
      commissionAmount: 55,
    }));
    expect(prisma.club_subscriptions.findMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({
        OR: expect.arrayContaining([
          { employee_id: 7 },
          { sales_id: 7 },
          { member: { is: { OR: [{ employee_id: 7 }, { sales_id: 7 }] } } },
        ]),
      }),
    }));
    expect(prisma.club_receipts.findMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({ receipt_date: { gte: '2026-09-01', lt: '2026-10-01' } }),
    }));
  });
});
